package controlador;

public class Principal 
{
	@SuppressWarnings("unused")
	public static void main(String[]args)
	{
		Controlador c = new Controlador();
	}
}
